import { Link } from "react-router-dom";
import "../css/navbar.css";
import { useAppDispatch } from "../redux/hooks";
import { getPosts } from "../redux/Thunk/getPosts";

function NavBar() {
  const dispatch = useAppDispatch();

  return (
    <div className="nav">
      <Link className="link" to="/">
        Home
      </Link>
      <div className="reload">
        <button onClick={() => dispatch(getPosts())}>Load posts</button>
      </div>
    </div>
  );
}

export default NavBar;
