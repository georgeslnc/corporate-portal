import "../css/home.css";
import { useAppSelector } from "../redux/hooks";
import { RootState, postType } from "../types/posts";

function Home() {
  const posts = useAppSelector((state: RootState) => state.PostsReducer.posts);
  const loading = useAppSelector(
    (state: RootState) => state.PostsReducer.loading
  );

  return (
    <div className="home-main">
      <div className="home-header">
        <p>Home</p>
      </div>
      {loading ? (
        <div className="loading">
          <img src="./loading.gif" alt="" />
        </div>
      ) : (
        <div className="posts-container">
          {posts.length ? (
            posts.map((post: postType, i) => (
              <div key={"post" + i} className="post">
                <div className="post-header">
                  <p className="title">{post.title}</p>
                  <div className="fav-btn"></div>
                </div>
                <div className="content">{post.body}</div>
              </div>
            ))
          ) : (
            <p className="noposts">No posts found</p>
          )}
        </div>
      )}
    </div>
  );
}

export default Home;
