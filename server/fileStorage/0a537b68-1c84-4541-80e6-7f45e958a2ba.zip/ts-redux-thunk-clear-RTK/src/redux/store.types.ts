import { postType } from "../types/posts";

export type stateType = {
  posts: postType[];
  loading: boolean;
};
