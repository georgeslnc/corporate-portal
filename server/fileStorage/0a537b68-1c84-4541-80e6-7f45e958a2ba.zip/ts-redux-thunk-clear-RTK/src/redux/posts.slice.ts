import { createSlice } from "@reduxjs/toolkit";
import { stateType } from "./store.types";
import { getPosts } from "./Thunk/getPosts";

const initialState: stateType = {
  posts: [],
  loading: false,
};

const postsSlice = createSlice({
  name: "posts",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getPosts.pending, (state) => {
        state.loading = true;
      })
      .addCase(getPosts.fulfilled, (state, action) => {
        state.loading = false;
        state.posts = [...action.payload];
      })
      .addCase(getPosts.rejected, (state) => {
        state.loading = false;
        console.error("ERROR!");
      })
      .addDefaultCase(() => {});
  },
});

export default postsSlice.reducer;
