import { configureStore } from "@reduxjs/toolkit";
import PostsReducer from "./posts.slice";

const store = configureStore({
  reducer: {
    PostsReducer,
  },
});

export default store;
