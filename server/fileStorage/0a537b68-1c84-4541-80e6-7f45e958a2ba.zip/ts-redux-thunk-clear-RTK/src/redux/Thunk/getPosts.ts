import { createAsyncThunk } from "@reduxjs/toolkit";
import { fetchPosts } from "./posts.api";

export const getPosts = createAsyncThunk("posts/fetchPosts", async () => {
  try {
    const response = await fetchPosts();
    return response;
  } catch (error) {
    return Promise.reject(new Error("400"));
  }
});
